<?php
class shape{
function draw(){
    echo'<h3>Draw Shape<br></h3>';
    
}

}
class circle extends shape{
    function draw(){
        echo'<h3>Draw Circle<br></h3>';
    }
}
$s = new shape;
$s->draw();

$c= new circle;
$c->draw();

?>