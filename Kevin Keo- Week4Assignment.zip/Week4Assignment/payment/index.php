
<?php

    require_once(__DIR__ . '/class/aba.php');
    require_once(__DIR__ . '/class/wing.php');
    require_once(__DIR__ . '/class/pipay.php');


echo "<h1>Online Payment</h1>";

$paymentmethod=[
    new aba("ITEM 1",3,7),
    new aba("ITEM 2",2,7),
    new wing("ITEM 3",4,9),
    new pipay("ITEM 4",3,6),
    new aba("ITEM 2",6,7),
    new wing("ITEM 3",5,9),
    new pipay("ITEM 4",5,6),
    new wing("ITEM 3",1,9),
    new aba("ITEM 2",3,7),
    new wing("ITEM 3",1,9),
    new pipay("ITEM 4",4,6),
    new aba("ITEM 2",2,7),
    new pipay("ITEM 4",3,6),
    new wing("ITEM 3",3,9),
    new wing("ITEM 3",7,9),

];
echo'<h2>1. Display ABA sale</h2>'; 
function displayABA($paymentmethod)
{
    echo '<table border="1">';
    echo '<tr>';
        echo '<th>Item</th>';
        echo '<th>Quantity</th>';
        echo '<th>Price</th>';
        echo '<th>Method</th>';
        echo '<th>Total</th>';
    echo '</tr>';
    foreach ($paymentmethod as $payment) {
        if(get_class($payment) == 'aba'){

        echo '<tr>';
            echo '<td>' .$payment->getItem() . '</td>';
            echo '<td>' .$payment->getQuantity() . '</td>';
            echo '<td>' .$payment->getPrice() . '</td>';
            echo '<td>' . get_class($payment) . '</td>';
            echo '<td>' . $payment->getTotal() . '</td>';
        echo '</tr>';
    }
    }
    echo '</table>';
}
displayABA($paymentmethod);

echo '<h2> 2. Display  PiPay and Wing sale</h2>'; 
function displayWnP($paymentmethod)
{
    echo '<table border="1">';
    echo '<tr>';
        echo '<th>Item</th>';
        echo '<th>Quantity</th>';
        echo '<th>Price</th>';
        echo '<th>Method</th>';
        echo '<th>Total</th>';
    echo '</tr>';
    foreach ($paymentmethod as $payment) {
        if(get_class($payment) == 'pipay' || get_class($payment) == 'wing' ){
            echo '<tr>';
            echo '<td>' .$payment->getItem() . '</td>';
            echo '<td>' .$payment->getQuantity() . '</td>';
            echo '<td>' .$payment->getPrice() . '</td>';
            echo '<td>' . get_class($payment) . '</td>';
            echo '<td>' . $payment->getTotal() . '</td>';
        echo '</tr>';
    }
    }
    echo '</table>';
}
displayWnP($paymentmethod);
echo '<h2>3. Display all sales ordering by biggest total amount </h2>';
function displayAll($paymentmethod){
    echo '<table border="1">';
    echo '<tr>';
        echo '<th>Item</th>';
        echo '<th>Quantity</th>';
        echo '<th>Price</th>';
        echo '<th>Method</th>';
        echo '<th>Total</th>';
    echo '</tr>';

    foreach ($paymentmethod as $payment) {
        echo '<tr>';
            echo '<td>' .$payment->getItem() . '</td>';
            echo '<td>' .$payment->getQuantity() . '</td>';
            echo '<td>' .$payment->getPrice() . '</td>';
            echo '<td>' . get_class($payment) . '</td>';
            echo '<td>' . $payment->getTotal() . '</td>';
        echo '</tr>';    
    }
  
    echo '</table>';

}
$clonePaymentMethod = $paymentmethod;
usort ($clonePaymentMethod, function ($item1, $item2)
{
    return $item2->getTotal() <=> $item1 -> getTotal();
});
displayAll($clonePaymentMethod); 



?>