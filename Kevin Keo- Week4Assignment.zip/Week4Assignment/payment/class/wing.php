<?php

class wing{
    protected $price;
    protected $quantity;
    protected $total;
    protected $item;

    public function __construct($item, $price, $quantity){
        $this->item= $item;
        $this->price= $price;
        $this->quantity= $quantity;

    }
    public function getTotal(){
        return $this->price * $this->quantity;
    }
    public function getItem(){
        return $this->item;
    }
    public function getPrice(){
        return $this->price;
    }
    public function getQuantity(){
        return $this->quantity;
    }
} 
?>